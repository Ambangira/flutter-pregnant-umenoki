///
/// Project name: Umenoki
/// Description: Nutrition subject page
/// Author: Xiao
/// Date: 2020-06-10
/// 

import 'package:flutter/material.dart';
import 'package:umenoki/src/app_theme.dart';
import 'package:umenoki/src/widgets/shape_border_widget.dart';
import 'package:sticky_headers/sticky_headers.dart';

class NutritionSubjectRecipePage extends StatefulWidget {

  @override
  State<StatefulWidget> createState() => new _NutritionSubjectRecipePageState();
}

class _NutritionSubjectRecipePageState extends State<NutritionSubjectRecipePage>{
  @override
  Widget build(BuildContext context) {
    final Map arguments = ModalRoute.of(context).settings.arguments as Map;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: _appBarWidget(context, arguments['title']),
      body: CustomScrollView(
        slivers: <Widget>[
          SliverList(
            delegate: SliverChildListDelegate(
              [
                _headerWidget(context),
                _bodyWidget(context),
              ],
            ),
          ),
        ],
      )
    );
  }

  Widget _appBarWidget(BuildContext context, String title) {
    return AppBar(
      title: Text(title, style: AppTheme.title,),
      centerTitle: true,
      backgroundColor: AppTheme.nearlyRed,
      shape: CustomShapeBorder(),
      // elevation: 5.0,
      leading: IconButton(
        icon: Icon(
          Icons.arrow_back,
          color: Colors.white,
        ),
        onPressed: () {
          Navigator.pushReplacementNamed(context, '/nutrition/subject/detail');
        },
      ),
      actions: <Widget>[
        IconButton(
          icon: ImageIcon(
            AssetImage("assets/components/nutrition/icn_plus.png"),
            size: AppTheme.iconSize,
            color: Colors.white,
          ),
          iconSize: AppTheme.iconSize,
          onPressed: (){

          },
        ),
      ],
    );
  }

  Widget _headerWidget(BuildContext context) {
    final Map arguments = ModalRoute.of(context).settings.arguments as Map;
    return Column(
      children: <Widget>[
        Container(
          margin: EdgeInsets.only(top: 40, bottom: 10),
          child: Image(
            image: AssetImage("assets/components/nutrition/img_subject_detail_item.png"),
            height: 200,
            fit: BoxFit.cover,
          ),
        ),
        Row(
          children: <Widget>[

          ],
        ),
      ],
    );
  }

  Widget _bodyWidget(BuildContext context) {
    List<String> listTitle = ['旬カツオのガーリックバターステーキ','マグロの照り焼きステーキ','旬カツオのガーリックバターステーキ','マグロの照り焼きステーキ','旬カツオのガーリックバターステーキ','マグロの照り焼きステーキ','旬カツオのガーリックバターステーキ','マグロの照り焼きステーキ',];
    return Container(
      margin: EdgeInsets.only(left: 10, right:10),
      child: GridView.builder(
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        itemCount: listTitle.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2,childAspectRatio: 0.85,),
        itemBuilder: (context, indx){
          return Container(
            margin: EdgeInsets.only(left: 5, top: 5, right: 5, bottom: 5),
            child: Column(
              children: <Widget>[
                Container(
                  margin: EdgeInsets.only(left: 5, right: 5),
                  height: 40,
                  child: RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(
                      text: listTitle[indx],
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.black,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    _onTileClicked(indx);
                  },
                  child:
                  Container(
                    margin: EdgeInsets.only(bottom: 5),
                    height: 100,
                    child: Center(
                      child: Image(
                        image: AssetImage("assets/components/nutrition/img_subject_detail_item.png"),
                        height:100,
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Image(
                      width: 20,
                      height: 12,
                      image: AssetImage("assets/components/nutrition/icn_heart.png"),
                      fit: BoxFit.contain,
                    ),
                    Container(
                      margin: EdgeInsets.only(right: 20),
                      child: Text(
                        '609',
                        style: TextStyle(
                          fontSize: 10,
                          color: Color(0xffE37E29),
                        ),
                      ),
                    ),
                    Image(
                      width: 20,
                      height: 12,
                      image: AssetImage("assets/components/nutrition/icn_like.png"),
                      fit: BoxFit.contain,
                    ),
                    Container(
                      margin: EdgeInsets.only(right: 10),
                      child: Text(
                          '120',
                          style: TextStyle(
                            fontSize: 10,
                            color: Color(0xffE37E29),
                          ),
                      ),
                    ),
                  ],
                )
              ],
            )
          );
        },
      ),
    );
  }

  void _onTileClicked(int index){
    debugPrint("You tapped on item $index");
  }
}
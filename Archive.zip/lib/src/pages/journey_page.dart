///
/// Project name : Umenoki
/// Description : Journey page
/// Author : Xiao
/// Date : 2020-06-02
///

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class JourneyPage extends StatefulWidget {

  @override
  State<StatefulWidget> createState() => new _JourneyPageState();
}

class _JourneyPageState extends State<JourneyPage>{
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text('Journey page'),
      )
    );
  }
}